# Ice-Cream-Parlour-Management-System

### Link For The .exe file 
    https://github.com/Vishal023/Ice-Cream-Parlour-Management-System/blob/master/icecream.exe?raw=true
    or,
    https://drive.google.com/open?id=1UgrHMLaaTKgUpDKKXENg-UiFsvirRjsl
